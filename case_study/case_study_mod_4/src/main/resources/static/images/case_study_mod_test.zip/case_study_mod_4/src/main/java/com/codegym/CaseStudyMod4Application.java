package com.codegym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaseStudyMod4Application {

    public static void main(String[] args) {
        SpringApplication.run(CaseStudyMod4Application.class, args);


    }

}
